
import React from 'react';
import { Building, Loader } from 'lucide-react';

const ConstructionAnimation: React.FC = () => {
  return (
    <div className="relative h-80 w-full md:h-96 overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-construction-lightgray blueprint-bg"></div>
      
      {/* Ground */}
      <div className="absolute bottom-0 left-0 right-0 h-12 bg-construction-gray"></div>
      
      {/* Building under construction */}
      <div className="absolute bottom-12 left-1/2 transform -translate-x-1/2 w-40 flex justify-center">
        {/* Building frame */}
        <div className="relative w-32 h-64 animate-build-up">
          <div className="absolute bottom-0 w-full bg-construction-navy bg-opacity-80 rounded-t-md" style={{ height: '100%' }}>
            {/* Windows */}
            <div className="grid grid-cols-3 gap-2 p-2 h-full">
              {Array.from({ length: 15 }).map((_, index) => (
                <div 
                  key={index} 
                  className="bg-yellow-100 bg-opacity-30 rounded-sm"
                ></div>
              ))}
            </div>
          </div>
        </div>
        
        {/* Building Icon */}
        <div className="absolute -top-8 left-1/2 transform -translate-x-1/2 animate-float">
          <Building size={32} className="text-construction-navy" />
        </div>
      </div>
      
      {/* Crane */}
      <div className="absolute bottom-12 right-10 w-20 h-72 animate-crane origin-bottom">
        <div className="absolute bottom-0 w-6 h-full bg-construction-yellow left-1/2 transform -translate-x-1/2"></div>
        <div className="absolute top-4 w-56 h-6 bg-construction-yellow right-3"></div>
        <div className="absolute top-4 w-2 h-20 bg-construction-yellow right-3"></div>
        <div className="absolute top-0 right-3 animate-pulse">
          <div className="w-4 h-4 rounded-full bg-red-500"></div>
        </div>
      </div>
      
      {/* Excavator */}
      <div className="absolute bottom-6 left-0 w-20 h-16 animate-excavate">
        <div className="relative">
          <div className="absolute bottom-0 w-16 h-6 bg-construction-yellow rounded-sm">
            {/* Tracks */}
            <div className="absolute bottom-0 w-full h-2 bg-gray-800"></div>
          </div>
          <div className="absolute bottom-6 left-6 w-8 h-4 bg-construction-yellow"></div>
          <div className="absolute bottom-6 left-10 w-12 h-2 bg-construction-yellow rotate-45 origin-left"></div>
          <div className="absolute bottom-6 left-20 w-6 h-4 bg-construction-yellow -rotate-45"></div>
        </div>
      </div>
      
      {/* Loading indicator */}
      <div className="absolute top-4 left-1/2 transform -translate-x-1/2">
        <Loader className="animate-spin text-construction-yellow w-8 h-8" />
      </div>
    </div>
  );
};

export default ConstructionAnimation;
