
import React from 'react';

const Logo: React.FC = () => {
  return (
    <div className="flex items-center gap-4">
      <div className="relative w-16 h-16">
        <img 
          src="/lovable-uploads/f4a94f1e-ee01-4c11-99e5-6f2343095991.png" 
          alt="LG Construction Logo" 
          className="w-full h-full object-contain animate-glow"
        />
      </div>
      <div className="flex flex-col items-start">
        <span className="font-extrabold tracking-wider text-construction-gold text-2xl md:text-3xl leading-none mb-1">
          L G CONSTRUCTION
        </span>
        <span className="text-xs text-gray-400 leading-none">
          Subsidiary of ST. Antony's Agencies
        </span>
      </div>
    </div>
  );
};

export default Logo;
