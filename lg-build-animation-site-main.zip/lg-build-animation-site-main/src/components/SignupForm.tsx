
import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { toast } from '@/hooks/use-toast';

const SignupForm: React.FC = () => {
  const [email, setEmail] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!email || !email.includes('@')) {
      toast({
        title: "Invalid email",
        description: "Please enter a valid email address.",
        variant: "destructive"
      });
      return;
    }
    
    setLoading(true);
    
    // Simulate API call
    setTimeout(() => {
      toast({
        title: "Success!",
        description: "Thank you for subscribing to our updates.",
      });
      setEmail('');
      setLoading(false);
    }, 1500);
  };

  return (
    <form onSubmit={handleSubmit} className="flex flex-col space-y-4 w-full max-w-md">
      <div className="flex flex-col sm:flex-row w-full gap-2">
        <Input
          type="email"
          placeholder="Enter your email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          className="flex-grow bg-construction-darkgray border-construction-gold/50 text-white"
          required
        />
        <Button 
          type="submit" 
          disabled={loading}
          className="bg-construction-gold hover:bg-construction-darkgold text-black"
        >
          {loading ? 'Subscribing...' : 'Notify Me'}
        </Button>
      </div>
      <p className="text-xs text-gray-400">
        We'll notify you when our website launches. No spam, we promise!
      </p>
    </form>
  );
};

export default SignupForm;
