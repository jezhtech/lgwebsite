
import React, { useState, useEffect } from 'react';

interface CountdownTimerProps {
  targetDate: Date;
}

const CountdownTimer: React.FC<CountdownTimerProps> = ({ targetDate }) => {
  const [timeLeft, setTimeLeft] = useState({
    days: 0,
    hours: 0,
    minutes: 0,
    seconds: 0
  });

  useEffect(() => {
    const calculateTimeLeft = () => {
      const difference = targetDate.getTime() - new Date().getTime();
      
      if (difference > 0) {
        setTimeLeft({
          days: Math.floor(difference / (1000 * 60 * 60 * 24)),
          hours: Math.floor((difference / (1000 * 60 * 60)) % 24),
          minutes: Math.floor((difference / 1000 / 60) % 60),
          seconds: Math.floor((difference / 1000) % 60)
        });
      }
    };

    calculateTimeLeft();
    const timer = setInterval(calculateTimeLeft, 1000);

    return () => clearInterval(timer);
  }, [targetDate]);

  return (
    <div className="flex justify-center space-x-4 md:space-x-6">
      <div className="flex flex-col items-center">
        <div className="text-3xl md:text-5xl font-bold text-construction-navy">{timeLeft.days}</div>
        <div className="text-sm uppercase text-gray-600">Days</div>
      </div>
      <div className="flex flex-col items-center">
        <div className="text-3xl md:text-5xl font-bold text-construction-navy">{timeLeft.hours}</div>
        <div className="text-sm uppercase text-gray-600">Hours</div>
      </div>
      <div className="flex flex-col items-center">
        <div className="text-3xl md:text-5xl font-bold text-construction-navy">{timeLeft.minutes}</div>
        <div className="text-sm uppercase text-gray-600">Minutes</div>
      </div>
      <div className="flex flex-col items-center">
        <div className="text-3xl md:text-5xl font-bold text-construction-navy">{timeLeft.seconds}</div>
        <div className="text-sm uppercase text-gray-600">Seconds</div>
      </div>
    </div>
  );
};

export default CountdownTimer;
