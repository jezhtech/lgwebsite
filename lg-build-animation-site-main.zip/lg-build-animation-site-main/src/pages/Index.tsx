
import React from 'react';
import Logo from "@/components/Logo";
import SignupForm from "@/components/SignupForm";
import { Building2, Mail, Phone, MapPin, Calendar } from "lucide-react";

const Index = () => {
  return (
    <div className="min-h-screen flex flex-col bg-construction-dark">
      {/* Header */}
      <header className="bg-construction-dark py-4 px-6 border-b border-construction-gold/20">
        <div className="container mx-auto">
          <Logo />
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-grow container mx-auto px-4 py-8 md:py-12">
        <div className="max-w-6xl mx-auto">
          {/* Hero Section */}
          <section className="text-center mb-16 relative">
            {/* Glow effect */}
            <div className="absolute -top-10 left-1/2 transform -translate-x-1/2 
              w-full max-w-4xl h-60 bg-construction-gold/10 
              rounded-full blur-[120px] opacity-30 -z-10"></div>
            
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-extrabold mb-4 text-white relative z-10">
              <span className="text-construction-gold">Constructing</span> Our Website
            </h1>
            <p className="text-lg md:text-xl text-gray-300 mb-6 max-w-2xl mx-auto relative z-10">
              We're building something amazing. Our new website is under development and will be ready soon.
            </p>
            <div className="w-full max-w-md mx-auto relative z-10">
              <SignupForm />
            </div>
          </section>

          {/* About Us Preview */}
          <section className="bg-construction-darkgray rounded-lg p-8 mb-16 border border-construction-gold/20">
            <div className="flex flex-col md:flex-row gap-8 items-center">
              <div className="md:w-1/3">
                <div className="p-4 bg-construction-dark rounded-lg shadow-md text-center border border-construction-gold/30">
                  <Building2 className="w-16 h-16 text-construction-gold mx-auto mb-4" />
                  <h3 className="text-xl font-bold text-white mb-2">LG CONSTRUCTION</h3>
                  <p className="text-gray-300">
                    A premier construction company with over 30 years of experience in commercial and residential projects.
                  </p>
                </div>
              </div>
              <div className="md:w-2/3">
                <h2 className="text-2xl md:text-3xl font-bold mb-4 text-construction-gold">
                  Building Excellence Since 1993
                </h2>
                <p className="text-gray-300 mb-4">
                  LG CONSTRUCTION has built over 1000+ houses, 500+ buildings, and 10+ churches with a commitment
                  to delivering high-quality construction services with integrity and professionalism.
                </p>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-6">
                  <div className="flex items-center">
                    <div className="w-10 h-10 rounded-full bg-construction-gold flex items-center justify-center mr-3">
                      <Phone className="w-5 h-5 text-black" />
                    </div>
                    <span className="text-gray-200">+91 9486756602</span>
                  </div>
                  <div className="flex items-center">
                    <div className="w-10 h-10 rounded-full bg-construction-gold flex items-center justify-center mr-3">
                      <Mail className="w-5 h-5 text-black" />
                    </div>
                    <span className="text-gray-200">info@lgconstruction.in</span>
                  </div>
                  <div className="flex items-center">
                    <div className="w-10 h-10 rounded-full bg-construction-gold flex items-center justify-center mr-3">
                      <Calendar className="w-5 h-5 text-black" />
                    </div>
                    <span className="text-gray-200">Building since 1993</span>
                  </div>
                  <div className="flex items-center">
                    <div className="w-10 h-10 rounded-full bg-construction-gold flex items-center justify-center mr-3">
                      <MapPin className="w-5 h-5 text-black" />
                    </div>
                    <span className="text-gray-200">Gnaravilai, Chemparuthi Vilai, Kanyakumari</span>
                  </div>
                </div>
              </div>
            </div>
          </section>
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-construction-dark text-white py-6 border-t border-construction-gold/20">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="mb-4 md:mb-0">
              <img 
                src="/lovable-uploads/f4a94f1e-ee01-4c11-99e5-6f2343095991.png" 
                alt="LG Construction Logo" 
                className="w-16 h-16 object-contain"
              />
            </div>
            <div className="text-center md:text-right">
              <p className="text-sm text-gray-300">
                &copy; {new Date().getFullYear()} LG CONSTRUCTION | Developed By Jezh Technologies
              </p>
              <p className="text-xs text-gray-400 mt-1">
                Full website coming soon
              </p>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Index;
